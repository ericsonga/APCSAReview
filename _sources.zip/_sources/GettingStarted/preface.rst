.. qnum::
   :prefix: 1-1-
   :start: 1

Preface
===============

I have published this book using a Creative Commons license to
encourage you to use it, change it, and modify it for your own purposes.
I would appreciate knowing what you think if you do use this book, and I
would love to see any modifications or additions you make.

Barbara Ericson `ericson@cc.gatech.edu <mailto://ericson@cc.gatech.edu>`_ January,
2014

    This work is licensed under a Creative Commons Attribution 3.0
    United States License. See http://creativecommons.org
    
This book is intended to help you review for the Advanced Placement Computer Science A Exam.  For more information on the exam see https://apstudent.collegeboard.org/apcourse/ap-computer-science-a/exam-practice.  