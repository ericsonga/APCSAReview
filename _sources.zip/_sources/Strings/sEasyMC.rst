.. qnum::
   :prefix: 4-7-
   :start: 1
   
Easy Multiple Choice Questions
------------------------------

These problems are easier than what you will see on the AP CS A exam.
