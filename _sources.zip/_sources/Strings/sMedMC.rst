.. qnum::
   :prefix: 4-8-
   :start: 1
   
Medium Multiple Choice Questions
----------------------------------

These problems are similar to those you will see on the AP CS A exam.
