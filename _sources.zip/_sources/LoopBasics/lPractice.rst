.. qnum::
   :prefix: 6-5-
   :start: 1

More Practice
===============
     
For more practice with loops and strings see http://codingbat.com/java/Warmup-2.  For practice with loops and arrays see http://codingbat.com/java/Array-2.