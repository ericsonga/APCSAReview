.. qnum::
   :prefix: 9-10-
   :start: 1

More Practice
============= 
For practice with free response questions and inheritance see Question 2 from 2012 at http://home.cc.gatech.edu/ice-gt/320, Question 2 from 2011 at http://home.cc.gatech.edu/ice-gt/306 or Question 2 from 2009 at http://coweb.cc.gatech.edu/ice-gt/1278.
