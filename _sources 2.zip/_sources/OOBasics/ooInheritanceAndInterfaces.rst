.. qnum::
   :prefix: 9-7-
   :start: 1

Inheritance and Interfaces
==========================

An **interface** in Java is a special type of abstract class that can only contain public abstract methods (the method is assumed to be ``public`` and ``abstract`` even if these keywords are not specified) and public class constants.  ``List`` is an interface in Java.  Interfaces are declared using the **interface** keyword.  One interface can inherit from another interface.

.. code-block:: java 

  public interface Checker
  {
  	boolean check (Object obj);
  }
  
The code above declares an interface called ``Checker`` that contains a public abstract method called ``check`` that returns true or false.  Classes that implement this interface must provide the body for the ``check`` method.  

Another example of an interface in Java is the **Iterator** interface.  It is used to loop through collection classes (classes that hold groups of objects like ``ArrayList``).

