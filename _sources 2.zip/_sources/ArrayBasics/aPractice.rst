.. qnum::
   :prefix: 7-7-
   :start: 1


More Practice
===============
   
For practice with simple array manipulation and conditionals, but no loops see http://codingbat.com/java/Array-1. 
For more practice with loops and arrays go to http://codingbat.com/java/Array-2.
