.. qnum::
   :prefix: 6-4-
   :start: 1

Common Mistakes
===============

  -  Forgetting to change the thing you are testing in a ``while`` loop and ending up with an infinite loop.  
  
  -  Getting the start and end conditions wrong on the ``for`` loop. 
  
  -  Jumping out of a loop too early by using one or more return statements inside of the loop.    
 