.. qnum::
   :prefix: 5-6-
   :start: 1

More Practice
===============
     
For more practice with conditionals, and especially complex conditionals, go to http://codingbat.com/java/Logic-1 and http://codingbat.com/java/Logic-2 