.. qnum::
   :prefix: 10-4-
   :start: 1


Common Mistakes
===============
  -  Missing the recursive call.  Be sure to look for a call to the same method.
  -  Getting confused about when a recursive method returns and what it returns.  
  -  Assuming you understand what the recursion is doing without tracing all of it. 